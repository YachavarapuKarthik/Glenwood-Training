package com.example.controllers;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DbTesting {

    private static final String JDBCURL = "jdbc:postgresql://192.168.2.3:5432/karthik";
    private static final String USER = "glace";
    private static final String DBPASSWORD = "glacenxt";

    public static void main(String[] args) {
    	DbTesting  dbTest = new DbTesting();
        dbTest.testDatabaseConnection("tsdfsdfsdfdfs ", "sdfaasdfsdf");
    }

    public void testDatabaseConnection(String username, String password) {
        Connection connection = null;
        PreparedStatement statement = null;

        try {
            // Load the PostgreSQL JDBC driver
            Class.forName("org.postgresql.Driver");

            // Establish the connection
            connection = DriverManager.getConnection(JDBCURL, USER, DBPASSWORD);
            System.out.println("Database connection established.");

            // Prepare the SQL statement
            String query = "INSERT INTO users (username, password) VALUES (?, ?)";
            statement = connection.prepareStatement(query);
            statement.setString(1, username);
            statement.setString(2, password);

            // Execute the update
            int rows = statement.executeUpdate();

            if (rows > 0) {
                System.out.println("User  added to the database successfully.");
            } else {
                System.out.println("There was an error adding the user.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("SQL error: " + e.getMessage());
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            System.out.println("JDBC Driver not found: " + e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("General error: " + e.getMessage());
        } finally {
            // Close resources
            try {
                if (statement != null) {
                    statement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
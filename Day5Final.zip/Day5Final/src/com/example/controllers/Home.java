package com.example.controllers;

import java.io.BufferedReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

@WebServlet("/lms/*")
public class Home extends HttpServlet {
    private static final long serialVersionUID = 1L;
    final String DBURL = "jdbc:postgresql://192.168.2.3:5432/karthik";
    final String USER = "glace";
    final String DBPASSWORD = "glacenxt";

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String pathInfo = request.getPathInfo();

        switch (pathInfo) {
            case "/register":
                handleRegister(request, response);
                break;
            case "/login":
                handleLogin(request, response);
                break;
            case "/student":
                handleStudent(request, response);
                break;
            case "/updateStudent":
            	updateStudent(request,response);
                break;
            default:
                response.setContentType("application/json");
                response.getWriter().write("{ \"message\": \"This is Endpoint 3\" }");
                break;
        }
    }

    // Handle POST request for /register
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String pathInfo = request.getPathInfo();

        switch (pathInfo) {
            case "/register":
                handleRegister(request, response);
                break;
            case "/login":
                handleLogin(request, response);
                break;
            case "/student":
                handleStudent(request, response);
                break;
            case "/updateStudent":
            	updateStudent(request,response);
                break;
            default:
                response.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
                response.getWriter().write("{ \"message\": \"Method Not Allowed\" }");
                break;
        }
    }

    // Handle the /register path
    private void handleRegister(HttpServletRequest request, HttpServletResponse response) throws IOException {
        StringBuilder sb = new StringBuilder();
        
        try (BufferedReader reader = request.getReader()) {
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
        }
        
        String formData = sb.toString();
        Gson gson = new Gson();
        
        JsonObject jsonObject = gson.fromJson(formData, JsonObject.class);
        
        String username = jsonObject.get("username").getAsString();
        String password = jsonObject.get("password").getAsString();
        System.out.println(username+" " + password);
        
        // Initialize the JSON response object
        JsonObject jsonResponse = new JsonObject();
        
        try {
            Class.forName("org.postgresql.Driver");
            Connection connection = DriverManager.getConnection(DBURL, USER, DBPASSWORD);

            String query = "INSERT INTO users (username, password) VALUES (?, ?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, username);
            statement.setString(2, password); 
            
            int rows = statement.executeUpdate();

            if (rows > 0) {
                jsonResponse.addProperty("message", "Registration successful!");
                response.setStatus(HttpServletResponse.SC_OK);
            } else {
                jsonResponse.addProperty("message", "Error during registration.");
                response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            }

            statement.close();
        } catch (SQLException e) {
            jsonResponse.addProperty("message", "SQL error: " + e.getMessage());
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        } catch (ClassNotFoundException e) {
            jsonResponse.addProperty("message", "JDBC Driver not found: " + e.getMessage());
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            jsonResponse.addProperty("message", "General error: " + e.getMessage());
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }

        // Set the response content type and return the JSON response
        response.setContentType("application/json");
        response.getWriter().write(jsonResponse.toString());
    }

    // Handle the /endpoint2 path
    private void handleLogin(HttpServletRequest request, HttpServletResponse response) throws IOException {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader reader = request.getReader()) {
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
        }
        String formData = sb.toString();
        Gson gson = new Gson();
        JsonObject json = gson.fromJson(formData, JsonObject.class);
        
        String username = json.get("username").getAsString();
        String password = json.get("password").getAsString();
        
        JsonObject responseJson = new JsonObject();

        try { 
        	Class.forName("org.postgresql.Driver");
            Connection connection = DriverManager.getConnection(DBURL, USER, DBPASSWORD);
            String query = "SELECT * FROM users WHERE username = ? AND password = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, username);
            statement.setString(2, password);
            
            ResultSet resultSet = statement.executeQuery();
            
            if (resultSet.next()) {  
                responseJson.addProperty("message", "success");
            } else {
                responseJson.addProperty("message", "failed");
            }
            
            statement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
            responseJson.addProperty("message", "Error: " + e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            responseJson.addProperty("message", "General error: " + e.getMessage());
        }

        response.setContentType("application/json");
        response.getWriter().write(responseJson.toString());
    }
    // Handle the /endpoint3 path
    private void handleStudent(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.getWriter().write("{ \"message\": \"This is Endpoint 3\" }");
    }
    
    private void updateStudent(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	
    	
    }
}

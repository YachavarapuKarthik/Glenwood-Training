package com.example.ownapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OwnapiApplicationTests {

	@Test
	void contextLoads() {
	}

}

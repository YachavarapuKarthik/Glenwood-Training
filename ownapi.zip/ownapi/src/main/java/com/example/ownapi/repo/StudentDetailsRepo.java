package com.example.ownapi.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.ownapi.model.StudentDetails;



public interface StudentDetailsRepo extends JpaRepository<StudentDetails, Integer> {
	
}
package com.example.ownapi.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.ownapi.model.Student;
import com.example.ownapi.model.StudentDTO;
import com.example.ownapi.model.StudentDetails;
import com.example.ownapi.service.StudentService;

@CrossOrigin("*")
@RestController
@RequestMapping
public class StudentController {

    @Autowired
    private StudentService studentService;

    @PostMapping("/addStudent")
    public String addStudent(@RequestBody StudentDTO studentDTO) {
       
        Student student = new Student();
        student.setId(studentDTO.getId());  
        student.setName(studentDTO.getName());
        student.setStandard(studentDTO.getStandard());

        
        StudentDetails studentDetails = new StudentDetails();
        studentDetails.setId(studentDTO.getId());  
        studentDetails.setAddress(studentDTO.getAddress());
        studentDetails.setPhone(studentDTO.getPhone());

       
        studentService.addStudentWithDetails(student, studentDetails);

        return "Student added successfully";
        
        
    }

    @DeleteMapping("/deleteStudent")
    public String deleteStudent(@RequestBody Map<String, Integer> payload) {
        int id = payload.get("id"); 
        System.out.println(id);
        studentService.deleteStudent(id);
        return "Student deleted successfully";
    }
}

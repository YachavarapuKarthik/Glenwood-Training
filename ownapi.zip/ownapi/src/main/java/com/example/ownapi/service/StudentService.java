package com.example.ownapi.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.ownapi.model.Student;
import com.example.ownapi.model.StudentDetails;
import com.example.ownapi.repo.StudentDetailsRepo;
import com.example.ownapi.repo.StudentRepo;

@Service
public class StudentService {

    @Autowired
    private StudentRepo studentRepo;

    @Autowired
    private StudentDetailsRepo studentDetailsRepo;

    @Transactional
    public void addStudentWithDetails(Student student, StudentDetails studentDetails) {
        
    	studentRepo.save(student);
        
        studentDetailsRepo.save(studentDetails);
    }

    @Transactional
    public void deleteStudent(int studentId) {
        Student student = studentRepo.findById(studentId)
            .orElseThrow(() -> new RuntimeException("Student not found with ID: " + studentId));
        
        System.out.println(student.getId());
        System.out.println(student.getName());
        
        studentRepo.delete(student);
    }
}

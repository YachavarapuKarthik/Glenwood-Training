package com.example.student.app;

import org.hibernate.Session;
import com.example.student.models.Employee;
import com.example.student.util.HibernateUtil;

public class Main {

    public static void main(String[] args) {
        // Get the session from Hibernate utility
        Session session = HibernateUtil.getSession();
        
        try {
            // Start a transaction
            session.beginTransaction();
            
            // Create a new Employee object
            Employee employee = new Employee();
            employee.setName("John Doe");
            
            // Save the employee
            session.save(employee);
            
            // Commit the transaction
            session.getTransaction().commit();
            
            System.out.println("Employee saved with ID: " + employee.getId());
        } finally {
            // Close the session factory
            HibernateUtil.close();
        }
    }
}

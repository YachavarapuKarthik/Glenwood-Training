package org.karthik;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

@WebServlet("/Login")
public class Login extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        final String DBURL = "jdbc:postgresql://192.168.2.3:5432/karthik";
        final String USER = "glace";
        final String DBPASSWORD = "glacenxt";

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        boolean isAuthenticated = false;

        try {
            Class.forName("org.postgresql.Driver");
            Connection connection = DriverManager.getConnection(DBURL, USER, DBPASSWORD);

            // SQL query to check if user exists
            String query = "SELECT * FROM users WHERE username = ? AND password = ?;";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, username);
            statement.setString(2, password);

            // Execute the query
            ResultSet rows = statement.executeQuery();

            // If a user is found
            if (rows.next()) {
                isAuthenticated = true;
            }

           ;
            statement.close();
            connection.close();

        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().println("SQL error: " + e.getMessage());
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            response.getWriter().println("JDBC Driver not found: " + e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("General error: " + e.getMessage());
        }

        // Redirect based on authentication
        if (isAuthenticated) {
            request.setAttribute("message", "Successfully logged in");
            RequestDispatcher dispatcher = request.getRequestDispatcher("home.jsp");
            dispatcher.forward(request, response);
        } else {
            request.setAttribute("error", "Invalid username or password");
            RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");
            dispatcher.forward(request, response);
        }
    }
}

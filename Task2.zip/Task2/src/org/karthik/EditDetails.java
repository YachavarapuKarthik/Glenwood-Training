package org.karthik;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/EditDetails")
public class EditDetails extends HttpServlet {
    private static final long serialVersionUID = 1L;

    

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	final String DBURL = "jdbc:postgresql://192.168.2.3:5432/karthik";
        final String USER = "glace";
        final String DBPSW = "glacenxt";
        
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String state = request.getParameter("state");
        String country = request.getParameter("country");
        String address = request.getParameter("address");
        String pincode = request.getParameter("pincode");
   
        

        try {
        	Class.forName("org.postgresql.Driver");
            Connection connection = DriverManager.getConnection(DBURL, USER, DBPSW);

            
            String query = "UPDATE students SET email = ?, phone = ?, state = ?, country = ?, address = ?, pincode = ? WHERE name = ?;";

            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, email);
            statement.setString(2, phone);
            statement.setString(3, state);
            statement.setString(4, country);
            statement.setString(5, address);
            statement.setString(6, pincode);
            statement.setString(7, name);

            
            int rows = statement.executeUpdate();

            if (rows>0) {
                request.setAttribute("message", "Successfully updated student details");
            } else {
                request.setAttribute("message", rows);
            }

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("message", e.getMessage());
        }

        request.getRequestDispatcher("home.jsp").forward(request, response);
    }

}

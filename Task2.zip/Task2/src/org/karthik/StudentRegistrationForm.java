package org.karthik;

import java.io.IOException;
import java.sql.Connection;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/StudentRegistrationForm")
public class StudentRegistrationForm extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        final String DBURL = "jdbc:postgresql://192.168.2.3:5432/karthik";
        final String USER = "glace";
        final String DBPASSWORD = "glacenxt";

        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String state = request.getParameter("state");
        String country = request.getParameter("country");
        String address = request.getParameter("address");
        String pincode = request.getParameter("pincode");
        String date = request.getParameter("date");
        
        java.util.Date utilDate = new java.util.Date();  
        java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());

        request.setAttribute("name", name);
        request.setAttribute("email", email);
        request.setAttribute("phone", phone);
        request.setAttribute("state", state);
        request.setAttribute("country", country);
        request.setAttribute("address", address);
        request.setAttribute("pincode", pincode);
        request.setAttribute("date", sqlDate);

        try {
            Class.forName("org.postgresql.Driver");
            Connection connection = DriverManager.getConnection(DBURL, USER, DBPASSWORD);

            String query = "INSERT INTO students (name, email, phone, state, country, address, pincode, date) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, name);
            statement.setString(2, email);
            statement.setString(3, phone);
            statement.setString(4, state);
            statement.setString(5, country);
            statement.setString(6, address);
            statement.setString(7, pincode);
            statement.setDate(8, sqlDate);

            int rows = statement.executeUpdate();

            if (rows > 0) {
                request.setAttribute("message", "Student registered successfully!");
            } else {
                request.setAttribute("message", "There was an error during registration.");
            }

            statement.close();
            connection.close();

        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("message", "Error: " + e.getMessage());
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            request.setAttribute("message", "JDBC Driver not found: " + e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("message", "General error: " + e.getMessage());
        }

        RequestDispatcher dispatcher = request.getRequestDispatcher("sucess.jsp");
        dispatcher.forward(request, response);
    }
}

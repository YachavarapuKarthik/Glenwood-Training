package org.karthik;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        final String DBURL = "jdbc:postgresql://192.168.2.3:5432/karthik";
        final String USER = "glace";
        final String DBPASSWORD = "glacenxt";

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        response.getWriter().append("Username: ").append(username);
        response.getWriter().append("Password: ").append(password);
        
        try {
            Class.forName("org.postgresql.Driver");
            Connection connection = DriverManager.getConnection(DBURL, USER, DBPASSWORD);

            String query = "INSERT INTO users (username, password) VALUES (?, ?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, username);
            statement.setString(2, password);

            int rows = statement.executeUpdate();

            if (rows > 0) {
        
                response.getWriter().println("DB is working now");
            } else {
                response.getWriter().println("There is an error");
            }

            statement.close();

        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().println("SQL error: " + e.getMessage());
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            response.getWriter().println("JDBC Driver not found: " + e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("General error: " + e.getMessage());
        }
        
        request.setAttribute("username",username);
        request.setAttribute("password",password);
        request.setAttribute("message","Succesfuly logged in");
        RequestDispatcher dispatcher = request.getRequestDispatcher("home.jsp");
        dispatcher.forward(request, response);
        
    }
    
    }



package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@Controller
public class HelloController {
    @GetMapping("/hello")
    public String index() {
        return "index";
    }
    
    @GetMapping("/")
    public String home() {
    	return "home";
    	
    }
    
    
    @GetMapping("/student")
    public String student() {
    	return "student";
    }
    
    
    @GetMapping("/staff-login")
    public String staffLogin() {
    	return "stafflogin";
    }
    
    @GetMapping("/staff-register")
    public String staffRegisteration(){
    	return "staffregister";
    }
    
    @GetMapping("/contact")
    public String contact() {
    	return "contact";
    }
    
}
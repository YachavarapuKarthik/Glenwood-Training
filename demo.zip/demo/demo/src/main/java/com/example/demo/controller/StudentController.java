package com.example.demo.controller;

import com.example.demo.model.Student;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class StudentController {

    // Show the registration form
    @RequestMapping("/registration")
    public String showForm(Model model) {
        model.addAttribute("student", new Student());
        return "student";  // This corresponds to the HTML file (registrationForm.html)
    }

    // Handle form submission
    @PostMapping("/submitRegistration")
    public String handleFormSubmit(@ModelAttribute Student student) {
        // Print the student details in the console
        System.out.println("Name: " + student.getName());
        System.out.println("Email: " + student.getEmail());
        System.out.println("Phone: " + student.getPhone());
        System.out.println("State: " + student.getState());
        System.out.println("Country: " + student.getCountry());
        System.out.println("Address: " + student.getAddress());
        System.out.println("Pincode: " + student.getPincode());
        System.out.println("Enrolled: " + student.getEnrolledDate());
        
        // You can add additional logic like saving to a database, etc.
        return "registrationSuccess";  // Redirect to a confirmation or success page
    }
}

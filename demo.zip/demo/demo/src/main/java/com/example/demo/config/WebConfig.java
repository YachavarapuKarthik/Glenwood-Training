package com.example.demo.config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**") // Allow all paths
                .allowedOrigins("http://localhost:5500/index.html") // Allow requests from your frontend (replace with your frontend URL)
                .allowedMethods("GET", "POST", "PUT", "DELETE") // Allow certain HTTP methods
                .allowCredentials(true); // Allow sending cookies (optional)
    }
}

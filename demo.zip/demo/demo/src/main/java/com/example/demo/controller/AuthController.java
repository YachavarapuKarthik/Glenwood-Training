package com.example.demo.controller;

import com.example.demo.model.LoginRequest;
import com.example.demo.model.LoginResponse;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "http://localhost:5500") 
@RestController
@RequestMapping("/auth")
public class AuthController {

    // Handle login POST request
    @PostMapping("/login")
    public LoginResponse login(@RequestBody LoginRequest loginRequest) {
        // Example login logic (you would validate credentials in a real app)
        boolean valid = "admin".equals(loginRequest.getUsername()) && "password123".equals(loginRequest.getPassword());

        LoginResponse response = new LoginResponse();
        response.setSuccess(valid);
        response.setMessage(valid ? "Login successful" : "Invalid credentials");

        return response;
    }
}